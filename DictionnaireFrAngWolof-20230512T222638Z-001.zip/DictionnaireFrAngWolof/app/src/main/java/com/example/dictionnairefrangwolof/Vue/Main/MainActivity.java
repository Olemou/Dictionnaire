package com.example.dictionnairefrangwolof.Vue.Main;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.example.dictionnairefrangwolof.R;
import com.example.dictionnairefrangwolof.Vue.Francais.FragmentAffichage_home;
import com.example.dictionnairefrangwolof.Vue.NavigationDrawer.ConnexionFragment;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_DictionnaireFrAngWolof_NoActionBar);
        setContentView(R.layout.activity_main);
        toolbar=findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);

        drawerLayout=findViewById(R.id.drawlayaout);
        navigationView=findViewById(R.id.navigation_NavavigationV);
        ActionBarDrawerToggle actionBarDrawerToggle= new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        if(savedInstanceState==null){
            LieFragmentUneActivite(new FragmentAffichage_home());
            navigationView.setCheckedItem(R.id.home_item);
        }

        navigationView.setNavigationItemSelectedListener(item -> {
            int id=item.getItemId();
            item.setCheckable(true);
            switch(id){
                case R.id.connexion_item:
                    LieFragmentUneActivite( new ConnexionFragment());
                    break;
                case R.id.home_item:
                    LieFragmentUneActivite(new FragmentAffichage_home());

                    break;



            }
            drawerLayout.closeDrawer(GravityCompat.START);

            return true;
        });

    }
    public void LieFragmentUneActivite(Fragment fragment){
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_pour_navigation,fragment)
                .commit();
    }

    public void LieFragmentUneActiviteDeconnexion(Fragment fragment){
        FirebaseAuth.getInstance().signOut();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_pour_navigation,fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
       else{ super.onBackPressed();}
    }
}
