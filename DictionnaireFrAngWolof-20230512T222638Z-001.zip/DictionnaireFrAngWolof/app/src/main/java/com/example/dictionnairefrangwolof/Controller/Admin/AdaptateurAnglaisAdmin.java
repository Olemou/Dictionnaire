package com.example.dictionnairefrangwolof.Controller.Admin;

import android.animation.LayoutTransition;
import android.app.AlertDialog;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Anglais.Anglais;
import com.example.dictionnairefrangwolof.R;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AdaptateurAnglaisAdmin extends RecyclerView.Adapter<AdaptateurAnglaisAdmin.ViewHolder> implements Filterable {

    ArrayList<Anglais> anglaisArrayList;
    ArrayList<Anglais> NewanglaisArrayList;
    Context context;

    public AdaptateurAnglaisAdmin(ArrayList<Anglais> anglaisArrayList, Context context) {
        this.anglaisArrayList = anglaisArrayList;
        this.context = context;
        NewanglaisArrayList=new ArrayList<>(anglaisArrayList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_mot_ang_admin,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Anglais anglais = anglaisArrayList.get(position);
        holder.setDetailMotsAnglais(anglais);
        String motsupp = anglais.getWord();

        holder.suprimmer.setOnClickListener(view -> {

            AlertDialog.Builder builder=new AlertDialog.Builder(holder.txtWordsAn.getContext());
            builder.setTitle("ATTENTION");
            builder.setMessage("Do you want to delete the data ?");
            builder.setPositiveButton("YES", (dialogInterface, i) -> FirebaseDatabase.getInstance().getReference("Mots").child("Anglais").
                    child(motsupp).removeValue()).setNegativeButton("NO", (dialogInterface, i) -> {
            });
            builder.show();
        });


        holder.modifier.setOnClickListener(view -> {
            final DialogPlus dialog = DialogPlus.newDialog(holder.txtWordsAn.getContext())
                    .setContentHolder(new com.orhanobut.dialogplus.ViewHolder(R.layout.update_mot_ang_admin))
                    .setExpanded(true,900)
                    .create();
            View v=dialog.getHolderView();

            EditText editWordsAn = v.findViewById(R.id.editWordsAn);
            EditText editDefinitionAn = v.findViewById(R.id.editDefinitionAn);
            EditText editWordsCRFA = v.findViewById(R.id.editWordsCRFA);
            EditText editWordsCRWA = v.findViewById(R.id.editWordsCRWA);

            Button buttonModifier;
            buttonModifier=v.findViewById(R.id.btnModifiermotsAn);

            editWordsAn.setText(anglais.getWord());
            editDefinitionAn.setText(anglais.getDefinition());
            editWordsCRFA.setText(anglais.getFrench());
            editWordsCRWA.setText(anglais.getWolof());
            dialog.show();

            buttonModifier.setOnClickListener(view1 -> {
                Map<String, Object> mots = new HashMap<>();
                mots.put("Word", editWordsAn.getText().toString());
                mots.put("Definition",editDefinitionAn.getText().toString());
                mots.put("French",editWordsCRFA.getText().toString());
                mots.put("Wolof",editWordsCRWA.getText().toString());
                FirebaseDatabase.getInstance().getReference("Mots").child("Anglais")
                        .child(editWordsAn.getText().toString()).updateChildren(mots).addOnSuccessListener(unused -> {
                    dialog.dismiss();
                    Toast.makeText(context.getApplicationContext(), "succes", Toast.LENGTH_SHORT).show();
                });

            });




        });


    }

    @Override
    public int getItemCount() {
        return anglaisArrayList.size();
    }

    public void filterList(ArrayList<Anglais> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        anglaisArrayList = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private final Filter exampleFilter= new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Anglais>FilteretudiantArrayList=new ArrayList<>();
            if(charSequence.toString().isEmpty()||charSequence.length()==0){
                FilteretudiantArrayList.addAll(NewanglaisArrayList)  ;
            } else{
                String motSaisie=charSequence.toString().toLowerCase();
                for(Anglais anglais:NewanglaisArrayList){
                    if(anglais.getWord().toLowerCase().contains(motSaisie)){
                        FilteretudiantArrayList.add(anglais);

                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=FilteretudiantArrayList;
            return  filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            anglaisArrayList.clear();
            anglaisArrayList.addAll((ArrayList)filterResults.values);
            notifyDataSetChanged();

        }
    };


    static class ViewHolder extends RecyclerView.ViewHolder{
        private final TextView txtWordsAn, txtDefMessageAn,txtDefinitionAn, txtMessageCRF, txtFrenchCRF, txtMessageCRWA, txtWolofCRWA;
        LinearLayout layoutDefinition, layoutCRF, layoutButtonAn, layoutCRWA;
        Button modifier, suprimmer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtWordsAn = itemView.findViewById(R.id.txtWordsAn);
            txtDefMessageAn = itemView.findViewById(R.id.txtDefMessageAn);
            txtDefinitionAn = itemView.findViewById(R.id.txtDefinitionAn);
            txtMessageCRF = itemView.findViewById(R.id.txtMessageCRF);
            txtFrenchCRF = itemView.findViewById(R.id.txtFrenchCRF);
            txtMessageCRWA = itemView.findViewById(R.id.txtMessageCRWA);
            txtWolofCRWA = itemView.findViewById(R.id.txtWolofCRWA);

            modifier = itemView.findViewById(R.id.btnModifierAn);
            suprimmer = itemView.findViewById(R.id.btnSuprimmerAn);

            // Initialisation des layouts
            layoutDefinition = itemView.findViewById(R.id.layoutDefinition);
            layoutDefinition.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRF = itemView.findViewById(R.id.layoutCRF);
            layoutCRF.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRWA = itemView.findViewById(R.id.layoutCRWA);
            layoutCRWA.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutButtonAn = itemView.findViewById(R.id.layoutButtonAn);
            layoutButtonAn.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            itemView.setOnClickListener(view -> {
                int Defmess = (txtDefMessageAn.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                int Def = (txtDefinitionAn.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                int Frmess = (txtMessageCRF.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRF, new AutoTransition());
                int French = (txtFrenchCRF.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRF, new AutoTransition());
                int Wolmess = (txtMessageCRWA.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRWA, new AutoTransition());
                int Wol = (txtWolofCRWA.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRWA, new AutoTransition());
                int edit = (modifier.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutButtonAn, new AutoTransition());
                int supp = (suprimmer.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                TransitionManager.beginDelayedTransition(layoutButtonAn, new AutoTransition());


                txtDefMessageAn.setVisibility(Defmess);
                txtDefinitionAn.setVisibility(Def);
                txtMessageCRF.setVisibility(Frmess);
                txtFrenchCRF.setVisibility(French);
                txtMessageCRWA.setVisibility(Wolmess);
                txtWolofCRWA.setVisibility(Wol);
                modifier.setVisibility(edit);
                suprimmer.setVisibility(supp);
            });




        }

        void setDetailMotsAnglais(Anglais anglais){
            txtWordsAn.setText(anglais.getWord());
            txtDefinitionAn.setText(anglais.getDefinition());
            txtFrenchCRF.setText(anglais.getFrench());
            txtWolofCRWA.setText(anglais.getWolof());
        }

    }

}
