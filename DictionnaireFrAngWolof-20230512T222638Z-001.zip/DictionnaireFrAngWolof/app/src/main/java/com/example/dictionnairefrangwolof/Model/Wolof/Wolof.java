package com.example.dictionnairefrangwolof.Model.Wolof;

public class Wolof {
    private String Mot;
    private String Anglais;
    private String Francais;

    public Wolof() {
    }

    public Wolof(String mot, String anglais, String francais) {
        Mot = mot;
        Anglais = anglais;
        Francais = francais;
    }

    public String getMot() {
        return Mot;
    }

    public void setMot(String mot) {
        Mot = mot;
    }

    public String getAnglais() {
        return Anglais;
    }

    public void setAnglais(String anglais) {
        Anglais = anglais;
    }

    public String getFrancais() {
        return Francais;
    }

    public void setFrancais(String francais) {
        Francais = francais;
    }
}
