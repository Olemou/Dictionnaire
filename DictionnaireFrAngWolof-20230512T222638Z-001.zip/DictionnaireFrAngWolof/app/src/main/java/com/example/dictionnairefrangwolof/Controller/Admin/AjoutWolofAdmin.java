package com.example.dictionnairefrangwolof.Controller.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.dictionnairefrangwolof.R;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AjoutWolofAdmin extends AppCompatActivity {

    private EditText editMotsWol, editMotsCRAW, editMotsCRFW;
    Button ajouterMotsWol, annulerMotsWol;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_wolof_admin);

        editMotsWol = findViewById(R.id.editMotsWol);
        editMotsCRAW = findViewById(R.id.editMotsCRAW);
        editMotsCRFW = findViewById(R.id.editMotsCRFW);

        annulerMotsWol = findViewById(R.id.btnAnnulermotsWol);
        annulerMotsWol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editMotsWol.setText("");
                editMotsCRAW.setText("");
                editMotsCRFW.setText("");
            }
        });
        ajouterMotsWol = findViewById(R.id.btnAjoutermotsWol);
        ajouterMotsWol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mot = editMotsWol.getText().toString();
                String anglais = editMotsCRAW.getText().toString();
                String francais = editMotsCRFW.getText().toString();

                if (TextUtils.isEmpty(mot)) {
                    editMotsWol.setError("Veuillez renseigner le mot ");
                } else if (TextUtils.isEmpty(anglais)) {
                    editMotsCRAW.setError("Veuillez renseigner la correspondance anglaise ");
                }    else if (TextUtils.isEmpty(francais)) {
                    editMotsCRFW.setError("Veuillez renseigner la correspondance francaise ");
                } else {
                    ajouterMotsWolFirebase(mot,anglais,francais);
                }
            }
        });


    }

    private void ajouterMotsWolFirebase(String mot, String anglais, String francais) {
        Map<String, Object> mots=new HashMap<>();
        mots.put("Mot",mot);
        mots.put("Anglais",anglais);
        mots.put("Francais",francais);

        // Ajout des données dans FIREBASE
        FirebaseDatabase.getInstance().getReference("Mots").child("Wolof").child(editMotsWol.getText().toString())
                .setValue(mots)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(getApplicationContext(),"Nouveau mot ajouté avec succes",Toast.LENGTH_LONG).show();
                    editMotsWol.setText("");
                    editMotsCRAW.setText("");
                    editMotsCRFW.setText("");
                    Intent i = new Intent(AjoutWolofAdmin.this, AdminWolAffichage.class);
                    startActivity(i);
                }).addOnFailureListener(e -> Toast.makeText(getApplicationContext(),"Echec d'ajout du mot",Toast.LENGTH_LONG).show());
    }
}