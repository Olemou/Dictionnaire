package com.example.dictionnairefrangwolof.Vue.Francais;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.dictionnairefrangwolof.Controller.Francais.adaptateurFr;
import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.R;
import com.example.dictionnairefrangwolof.Vue.Anglais.AffichageAnglais;
import com.example.dictionnairefrangwolof.Vue.Main.MainActivity;
import com.example.dictionnairefrangwolof.Vue.Wolof.affichageWolf;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**

 * create an instance of this fragment.
 */
public class FragmentAffichage_home extends Fragment {

    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    ArrayList<Mots>  mots;
    adaptateurFr recylerAdapter;
    Toolbar toolbar;
    SwipeRefreshLayout swipeRefreshLayout;


    public FragmentAffichage_home() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_affichage_home, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        toolbar=view.findViewById(R.id.toolbar_admin);
        swipeRefreshLayout=view.findViewById(R.id.swipes);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(false);
            }
        });


        ((MainActivity)getActivity()).setSupportActionBar(toolbar);
        setHasOptionsMenu(true);
        recyclerView = view.findViewById(R.id.recyle);
        //FirebaseDatabase.getInstance().getReference("Mots").keepSynced(true);
        bulid();



    }


    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.search_menu_fr,menu);
        MenuItem searchItem=menu.findItem(R.id.search_french);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setQueryHint("Rechercher un mot");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filter(s);
                return false;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }

    public void bulid(){

        databaseReference = FirebaseDatabase.getInstance().getReference("Mots").child("Francais");


        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mots = new ArrayList<>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mots.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    // loadingPB.setVisibility(View.GONE);

                    mots.add(dataSnapshot.getValue(Mots.class));
                }

                recylerAdapter.notifyDataSetChanged();
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });    //databaseReference.addListenerForSingleValueEvent(valueEventListener)
        recylerAdapter = new adaptateurFr(mots, getContext());
        recyclerView.setAdapter(recylerAdapter);
    }
    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<Mots> filteredlist = new ArrayList<>();

        // running a for loop to compare elements.
        for (Mots item : mots) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getMot().toLowerCase().contains(text.toLowerCase()) ) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(getContext(), "Vide..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            recylerAdapter.filterList(filteredlist);
        }
    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemSelect=item.getItemId();
        switch(itemSelect){
            case R.id.wolof:
                Intent intent1=new Intent(getContext(), affichageWolf.class);
                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent1);
                break;
            case R.id.anglais:
                Intent intent=new Intent(getContext(), AffichageAnglais.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                break;
            case R.id.francais:
                Intent intent2=new Intent(getContext(), MainActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent2);

        }

        return super.onOptionsItemSelected(item);
    }


}