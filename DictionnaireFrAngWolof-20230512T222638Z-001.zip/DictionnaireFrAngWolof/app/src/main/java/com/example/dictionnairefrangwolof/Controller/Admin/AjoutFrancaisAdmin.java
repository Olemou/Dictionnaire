package com.example.dictionnairefrangwolof.Controller.Admin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.dictionnairefrangwolof.R;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AjoutFrancaisAdmin extends Activity {
    private EditText editMotsFr , editTypeFr, editDescriptionFr, editMotsCRA, editMotsCRW;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ajout_admin);

        // Initialisation des EditText Français
        editMotsFr = findViewById(R.id.editMotsFr);
        editTypeFr = findViewById(R.id.editTypeFr);
        editDescriptionFr = findViewById(R.id.editDescriptionFr);
        editMotsCRA = findViewById(R.id.editMotsCRA);
        editMotsCRW = findViewById(R.id.editMotsCRW);


        Button annuler = findViewById(R.id.btnAnnulermotsFr);
        annuler.setOnClickListener(view -> {
            editMotsFr.setText("");
            editTypeFr.setText("");
            editDescriptionFr.setText("");
            editMotsCRA.setText("");
            editMotsCRW.setText("");
        });

        Button ajouterMots = findViewById(R.id.btnAjoutermotsFr);

        ajouterMots.setOnClickListener(view -> {

            // Pour la partie français
            String mot = editMotsFr.getText().toString();
            String type = editTypeFr.getText().toString();
            String description = editDescriptionFr.getText().toString();
            String correspondanceanglais= editMotsCRA.getText().toString();
            String correspondancewolof= editMotsCRW.getText().toString();

            if (TextUtils.isEmpty(mot)) {
                editMotsFr.setError("Veuillez renseigner le mot ");
            } else if (TextUtils.isEmpty(type)) {
                editTypeFr.setError("Veuillez renseigner le type du mot ");
            }    else if (TextUtils.isEmpty(description)) {
                editDescriptionFr.setError("Veuillez renseigner la définition du mot ");
            } else if(TextUtils.isEmpty(correspondanceanglais)){
                editMotsCRA.setError("Veuillez renseigner la correspondance du mot ");
            } else if(TextUtils.isEmpty(correspondancewolof)){
                editMotsCRW.setError("Veuillez renseigner la correspondance du mot ");
            }

            else {
                ajouterMotsFirebase(mot,type,description,correspondanceanglais,correspondancewolof);
            }
        });
    }


    private void ajouterMotsFirebase(String mot, String type, String description, String correspondanceanglais, String correspondancewolof ) {
        Map<String, Object> mots=new HashMap<>();
        mots.put("Mot",mot);
        mots.put("Type",type);
        mots.put("Definition",description);
        mots.put("CorespondanceAnglais", correspondanceanglais);
        mots.put("CorespondanceWolof", correspondancewolof);

        // Ajout des données dans FIREBASE
        FirebaseDatabase.getInstance().getReference("Mots").child("Francais").child(editMotsFr.getText().toString())
                .setValue(mots)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(getApplicationContext(),"Nouveau mot ajouté avec succes",Toast.LENGTH_LONG).show();
                    editMotsFr.setText("");
                    editTypeFr.setText("");
                    editDescriptionFr.setText("");
                    editMotsCRA.setText("");
                    editMotsCRW.setText("");
                    Intent i = new Intent(AjoutFrancaisAdmin.this, AdminFrAffichage.class);
                    startActivity(i);
                }).addOnFailureListener(e -> Toast.makeText(getApplicationContext(),"Echec d'ajout du mot",Toast.LENGTH_LONG).show());
    }
    }

