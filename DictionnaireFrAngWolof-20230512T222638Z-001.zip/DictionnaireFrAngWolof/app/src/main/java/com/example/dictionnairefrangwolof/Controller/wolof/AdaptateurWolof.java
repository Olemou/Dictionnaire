package com.example.dictionnairefrangwolof.Controller.wolof;

import android.animation.LayoutTransition;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Wolof.Wolof;
import com.example.dictionnairefrangwolof.R;

import java.util.ArrayList;


public class AdaptateurWolof extends RecyclerView.Adapter<AdaptateurWolof.ViewHolder> implements Filterable {

    ArrayList<Wolof> wolofArrayList;
    ArrayList<Wolof> NewwolofArrayList;
    Context context;

    public AdaptateurWolof(ArrayList<Wolof> wolofArrayList, Context context) {
        this.wolofArrayList = wolofArrayList;
        this.context = context;
        NewwolofArrayList=new ArrayList<>(wolofArrayList);
    }

    @NonNull
    @Override
    public AdaptateurWolof.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_wolof_utilisateur,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AdaptateurWolof.ViewHolder holder, int position) {

        Wolof wolof = wolofArrayList.get(position);
        holder.setDetailsMotsWolof(wolof);


      

        




      
    }

    @Override
    public int getItemCount() {
        return wolofArrayList.size();
    }

    public void filterList(ArrayList<Wolof> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        wolofArrayList = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }


    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private final Filter exampleFilter= new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Wolof>FilteretudiantArrayList=new ArrayList<>();
            if(charSequence.toString().isEmpty()||charSequence.length()==0){
                FilteretudiantArrayList.addAll(NewwolofArrayList)  ;
            } else{
                String motSaisie=charSequence.toString().toLowerCase();
                for(Wolof wolof:NewwolofArrayList){
                    if(wolof.getMot().toLowerCase().contains(motSaisie)){
                        FilteretudiantArrayList.add(wolof);

                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=FilteretudiantArrayList;
            return  filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            wolofArrayList.clear();
            wolofArrayList.addAll((ArrayList)filterResults.values);
            notifyDataSetChanged();

        }
    };



    static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtMotWol;
        private final TextView txtMessageCRAW;
        private final TextView txtAnglaisCRAW;
        private final TextView txtMessageCRFW;
        private final TextView txtFrancaisCRFW;

        LinearLayout layoutCRAW, layoutCRFW;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtMotWol = itemView.findViewById(R.id.txtMotsWol);
            txtMessageCRAW = itemView.findViewById(R.id.txtMessageCRAW);
            txtAnglaisCRAW = itemView.findViewById(R.id.txtAnglaisCRAW);
            txtMessageCRFW = itemView.findViewById(R.id.txtMessageCRFW);
            txtFrancaisCRFW = itemView.findViewById(R.id.txtFrancaisCRFW);



            layoutCRAW = itemView.findViewById(R.id.layoutCRAW);
            layoutCRAW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRFW = itemView.findViewById(R.id.layoutCRFW);
            layoutCRFW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);


            itemView.setOnClickListener(view -> {
                int txtMessCRAW = (txtMessageCRAW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRAW, new AutoTransition());
                int AnglaisCRAW = (txtAnglaisCRAW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRAW, new AutoTransition());
                int txtMessCRFW = (txtMessageCRFW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRFW, new AutoTransition());
                int FrancaisCRFW = (txtFrancaisCRFW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRFW, new AutoTransition());


                txtMessageCRAW.setVisibility(txtMessCRAW);
                txtAnglaisCRAW.setVisibility(AnglaisCRAW);
                txtMessageCRFW.setVisibility(txtMessCRFW);
                txtFrancaisCRFW.setVisibility(FrancaisCRFW);




            });
        }

        void setDetailsMotsWolof(Wolof wolof) {
            txtMotWol.setText(wolof.getMot());
            txtAnglaisCRAW.setText(wolof.getAnglais());
            txtFrancaisCRFW.setText(wolof.getFrancais());

        }
    }
}
