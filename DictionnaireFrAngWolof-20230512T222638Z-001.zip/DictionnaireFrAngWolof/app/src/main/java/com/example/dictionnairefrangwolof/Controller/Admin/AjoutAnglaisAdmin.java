package com.example.dictionnairefrangwolof.Controller.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.dictionnairefrangwolof.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AjoutAnglaisAdmin extends AppCompatActivity {
    private EditText editWordsAn , editDefinitionAn, editWordsCRF, editWordsCRW;
    private Button ajouter, annuler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_anglais_admin);

        editWordsAn = findViewById(R.id.editWordsAn);
        editDefinitionAn = findViewById(R.id.editDefinitionAn);
        editWordsCRF = findViewById(R.id.editWordsCRF);
        editWordsCRW = findViewById(R.id.editWordsCRW);

        ajouter = findViewById(R.id.btnAddWordsAn);
        annuler = findViewById(R.id.btnCancelAn);

        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String word = editWordsAn.getText().toString();
                String definition = editDefinitionAn.getText().toString();
                String french = editWordsCRF.getText().toString();
                String wolof = editWordsCRW.getText().toString();

                if (TextUtils.isEmpty(word)) {
                    editWordsAn.setError("Please enter the word ");
                } else if (TextUtils.isEmpty(definition)) {
                    editDefinitionAn.setError("Please enter the definition ");
                } else if(TextUtils.isEmpty(french)){
                    editWordsCRF.setError("Please enter the correspondance of the word ");
                } else if(TextUtils.isEmpty(wolof)){
                    editWordsCRW.setError("Please enter the correspondance of the word ");
                } else {
                    addWordsFirebase(word,definition,french,wolof);
                }

            }
        });

        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    private void addWordsFirebase(String word, String definition, String french, String wolof ) {
        Map<String, Object> words=new HashMap<>();
        words.put("Word",word);
        words.put("Definition",definition);
        words.put("French",french);
        words.put("Wolof",wolof);

        // Ajout des données dans FIREBASE
        FirebaseDatabase.getInstance().getReference("Mots").child("Anglais").child(editWordsAn.getText().toString())
                .setValue(words)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(),"New word added successfully",Toast.LENGTH_LONG).show();
                        editWordsAn.setText("");
                        editDefinitionAn.setText("");
                        editWordsCRF.setText("");
                        editWordsCRW.setText("");
                        Intent i = new Intent(AjoutAnglaisAdmin.this, AdminAngAffichage.class);
                        startActivity(i);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"Failed to add the word",Toast.LENGTH_LONG).show();
            }
        });
    }
}