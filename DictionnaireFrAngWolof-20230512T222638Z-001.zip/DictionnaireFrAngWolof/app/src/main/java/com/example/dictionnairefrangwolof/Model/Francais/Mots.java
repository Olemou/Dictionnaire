package com.example.dictionnairefrangwolof.Model.Francais;

public class Mots {
    private String Mot;
    private String Type;
    private String Definition;
    private String CorespondanceAnglais;
    private String CorespondanceWolof;

    public Mots() {
    }

    public Mots(String mot, String type, String definition, String corespondanceAnglais, String corespondanceWolof) {
        Mot = mot;
        Type = type;
        Definition = definition;
        CorespondanceAnglais = corespondanceAnglais;
        CorespondanceWolof = corespondanceWolof;
    }

    public String getMot() {
        return Mot;
    }

    public void setMot(String mot) {
        Mot = mot;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getDefinition() {
        return Definition;
    }

    public void setDefinition(String definition) {
        Definition = definition;
    }

    public String getCorespondanceAnglais() {
        return CorespondanceAnglais;
    }

    public void setCorespondanceAnglais(String corespondanceAnglais) {
        CorespondanceAnglais = corespondanceAnglais;
    }

    public String getCorespondanceWolof() {
        return CorespondanceWolof;
    }

    public void setCorespondanceWolof(String corespondanceWolof) {
        CorespondanceWolof = corespondanceWolof;
    }
}
