package com.example.dictionnairefrangwolof.Controller.Admin;

import android.animation.LayoutTransition;
import android.app.AlertDialog;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.R;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AdaptateurFrancaisAdmin extends RecyclerView.Adapter<AdaptateurFrancaisAdmin.ViewHolder> implements Filterable {


    ArrayList<Mots> motsArrayList;
    ArrayList<Mots> NewMotsArrayList;
    Context context;

    public AdaptateurFrancaisAdmin(ArrayList<Mots> motsArrayList, Context context) {
        this.motsArrayList = motsArrayList ;
        this.context = context;
        NewMotsArrayList=new ArrayList<>(motsArrayList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.liste_mot_fr_admin,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Mots mot = motsArrayList.get(position);
        holder.setDetailsEtudiant(mot);
        String motsupp = mot.getMot();

        holder.suprimmer.setOnClickListener(view -> {

            AlertDialog.Builder builder=new AlertDialog.Builder(holder.txtMotFr.getContext());
            builder.setTitle("ATTENTION");
            builder.setMessage("Voulez-vous suprimmer les données ?");
            builder.setPositiveButton("OUI", (dialogInterface, i) -> FirebaseDatabase.getInstance().getReference("Mots").child("Francais").
                    child(motsupp).removeValue()).setNegativeButton("NON", (dialogInterface, i) -> {
            });
            builder.show();
        });


        holder.modifier.setOnClickListener(view -> {
            final DialogPlus dialog = DialogPlus.newDialog(holder.txtMotFr.getContext())
                    .setContentHolder(new com.orhanobut.dialogplus.ViewHolder(R.layout.update_mot_fr_admin))
                    .setExpanded(true,900)
                    .create();
            View v=dialog.getHolderView();

            EditText editMotsFr = v.findViewById(R.id.editMotsFr);
            EditText editTypeFr = v.findViewById(R.id.editTypeFr);
            EditText editDescriptionFr = v.findViewById(R.id.editDescriptionFr);
            EditText editAnglaisCRA = v.findViewById(R.id.editMotsCRAUP);
            EditText editWolofCRW = v.findViewById(R.id.editMotsCRWUP);

            Button buttonModifier;
            buttonModifier=v.findViewById(R.id.btnModifiermotsFr);

            editMotsFr.setText(mot.getMot());
            editTypeFr.setText(mot.getType());
            editDescriptionFr.setText(mot.getDefinition());
            editAnglaisCRA.setText(mot.getCorespondanceAnglais());
            editWolofCRW.setText(mot.getCorespondanceWolof());
            dialog.show();

            buttonModifier.setOnClickListener(view1 -> {
                Map<String, Object> mots=new HashMap<>();
                mots.put("Mot", editMotsFr.getText().toString());
                mots.put("Type",editTypeFr.getText().toString());
                mots.put("Definition",editDescriptionFr.getText().toString());
                mots.put("CorespondanceAnglais",editAnglaisCRA.getText().toString());
                mots.put("CorespondanceWolof",editWolofCRW.getText().toString());
                FirebaseDatabase.getInstance().getReference("Mots").child("Francais")
                        .child(editMotsFr.getText().toString()).updateChildren(mots).addOnSuccessListener(unused -> {
                            dialog.dismiss();
                            Toast.makeText(context.getApplicationContext(), "succes", Toast.LENGTH_SHORT).show();
                        });

            });


        });

    }

    @Override
    public int getItemCount() {
        return motsArrayList.size();
    }

    public void filterList(ArrayList<Mots> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        motsArrayList = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }
    private Filter exampleFilter= new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Mots>FilteretudiantArrayList=new ArrayList<>();
            if(charSequence.toString().isEmpty()||charSequence.length()==0){
                FilteretudiantArrayList.addAll(NewMotsArrayList)  ;
            } else{
                String motSaisie=charSequence.toString().toLowerCase();
                for(Mots mots:NewMotsArrayList){
                    if(mots.getMot().toLowerCase().contains(motSaisie)){
                        FilteretudiantArrayList.add(mots);

                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=FilteretudiantArrayList;
            return  filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            motsArrayList.clear();
            motsArrayList.addAll((ArrayList)filterResults.values);
            notifyDataSetChanged();

        }
    };

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtMotFr, txtTypeFr, txtTypeMessageFr, txtDescriptionFr,txtDescMessageFr,
                txtMessageCra, txtAnglaisCRA, txtMessageCRW, txtWolofCRW;
        Button modifier, suprimmer;
        LinearLayout layoutType, layoutDefinition, layoutCRA, layoutButton, layoutCRW;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialisation de nos variables
            txtMotFr = itemView.findViewById(R.id.txtMotsFr);
            txtTypeMessageFr = itemView.findViewById(R.id.txtTypeMessageFr);
            txtTypeFr = itemView.findViewById(R.id.txtTypeFr);
            txtDescMessageFr = itemView.findViewById(R.id.txtDescMessageFr);
            txtDescriptionFr = itemView.findViewById(R.id.txtDescriptionFr);
            txtMessageCra = itemView.findViewById(R.id.txtMessageCRA);
            txtAnglaisCRA = itemView.findViewById(R.id.txtAnglaisCRA);
            txtMessageCRW = itemView.findViewById(R.id.txtMessageCRW);
            txtWolofCRW = itemView.findViewById(R.id.txtWolofCRW);

            modifier = itemView.findViewById(R.id.btnModifier);
            suprimmer = itemView.findViewById(R.id.btnSuprimmer);

            // Initialisation des layouts
            layoutType = itemView.findViewById(R.id.layoutType);
            layoutType.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutDefinition = itemView.findViewById(R.id.layoutDefinition);
            layoutDefinition.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRA = itemView.findViewById(R.id.layoutCRA);
            layoutCRA.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRW = itemView.findViewById(R.id.layoutCRW);
            layoutCRW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutButton = itemView.findViewById(R.id.layoutButton);
            layoutButton.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            // Bouton drop down pour afficher
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int typemess = (txtTypeMessageFr.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutType, new AutoTransition());
                    int type = (txtTypeFr.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutType, new AutoTransition());
                    int defmess = (txtDescMessageFr.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                    int def = (txtDescriptionFr.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                    int CRAmess = (txtMessageCra.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRA, new AutoTransition());
                    int CRA = (txtAnglaisCRA.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRA, new AutoTransition());
                    int CRWmess = (txtMessageCRW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRW, new AutoTransition());
                    int CRW = (txtWolofCRW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRW, new AutoTransition());


                    int btnmodif = (modifier.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutButton, new AutoTransition());
                    int btnsup = (suprimmer.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutButton, new AutoTransition());

                    txtTypeMessageFr.setVisibility(typemess);
                    txtTypeFr.setVisibility(type);
                    txtDescMessageFr.setVisibility(defmess);
                    txtDescriptionFr.setVisibility(def);
                    txtMessageCra.setVisibility(CRAmess);
                    txtAnglaisCRA.setVisibility(CRA);
                    txtMessageCRW.setVisibility(CRWmess);
                    txtWolofCRW.setVisibility(CRW);
                    modifier.setVisibility(btnmodif);
                    suprimmer.setVisibility(btnsup);


                }
            });





        }

        void setDetailsEtudiant(Mots mot) {
            txtMotFr.setText(mot.getMot());
            txtTypeFr.setText(mot.getType());
            txtDescriptionFr.setText(mot.getDefinition());
            txtAnglaisCRA.setText(mot.getCorespondanceAnglais());
            txtWolofCRW.setText(mot.getCorespondanceWolof());


        }
    }

}
