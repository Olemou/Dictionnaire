package com.example.dictionnairefrangwolof.Model.Anglais;

public class Anglais {

    private String Word;
    private String Definition;
    private String French;
    private String Wolof;

    public Anglais() {
    }

    public Anglais(String word, String definition, String french, String wolof) {
        Word = word;
        Definition = definition;
        French = french;
        Wolof = wolof;
    }

    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }

    public String getDefinition() {
        return Definition;
    }

    public void setDefinition(String definition) {
        Definition = definition;
    }

    public String getFrench() {
        return French;
    }

    public void setFrench(String french) {
        French = french;
    }

    public String getWolof() {
        return Wolof;
    }

    public void setWolof(String wolof) {
        Wolof = wolof;
    }
}
