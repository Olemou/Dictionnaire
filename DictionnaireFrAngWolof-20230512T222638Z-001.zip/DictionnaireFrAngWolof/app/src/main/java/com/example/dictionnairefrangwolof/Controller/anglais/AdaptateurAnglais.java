package com.example.dictionnairefrangwolof.Controller.anglais;

import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Anglais.Anglais;
import com.example.dictionnairefrangwolof.R;

import java.util.ArrayList;



import java.util.ArrayList;

    public class AdaptateurAnglais extends RecyclerView.Adapter<AdaptateurAnglais.ViewHolder> implements Filterable
    {


        ArrayList<Anglais> anglaisArrayList;
        ArrayList<Anglais> NewanglaisArrayList;
        Context context;

        public AdaptateurAnglais(ArrayList<Anglais> anglaisArrayList, Context context) {
            this.anglaisArrayList = anglaisArrayList;
            this.context = context;
            NewanglaisArrayList=new ArrayList<>(anglaisArrayList);
        }

        @NonNull
        @Override
        public AdaptateurAnglais.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_mot_ang_admin,parent,false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptateurAnglais.ViewHolder holder, int position) {

            Anglais anglais = anglaisArrayList.get(position);
            holder.setDetailMotsAnglais(anglais);











        }

        @Override
        public int getItemCount() {
            return anglaisArrayList.size();
        }

        @Override
        public Filter getFilter() {
            return exampleFilter;
        }

        private final Filter exampleFilter= new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                ArrayList<Anglais>FilteretudiantArrayList=new ArrayList<>();
                if(charSequence.toString().isEmpty()||charSequence.length()==0){
                    FilteretudiantArrayList.addAll(NewanglaisArrayList)  ;
                } else{
                    String motSaisie=charSequence.toString().toLowerCase();
                    for(Anglais anglais:NewanglaisArrayList){
                        if(anglais.getWord().toLowerCase().contains(motSaisie)){
                            FilteretudiantArrayList.add(anglais);

                        }
                    }
                }
                FilterResults filterResults=new FilterResults();
                filterResults.values=FilteretudiantArrayList;
                return  filterResults;
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

                anglaisArrayList.clear();
                anglaisArrayList.addAll((ArrayList)filterResults.values);
                notifyDataSetChanged();

            }
        };


        static class ViewHolder extends RecyclerView.ViewHolder{
            private final TextView txtWordsAn;
            private final TextView txtDefMessageAn;
            private final TextView txtDefinitionAn;
            private final TextView txtMessageCRF;
            private final TextView txtFrenchCRF;
            private final TextView txtMessageCRWA;
            private final TextView txtWolofCRWA;
            LinearLayout layoutDefinition, layoutCRF, layoutButtonAn, layoutCRWA;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                txtWordsAn = itemView.findViewById(R.id.txtWordsAn);
                txtDefMessageAn = itemView.findViewById(R.id.txtDefMessageAn);
                txtDefinitionAn = itemView.findViewById(R.id.txtDefinitionAn);
                txtMessageCRF = itemView.findViewById(R.id.txtMessageCRF);
                txtFrenchCRF = itemView.findViewById(R.id.txtFrenchCRF);
                txtMessageCRWA = itemView.findViewById(R.id.txtMessageCRWA);
                txtWolofCRWA = itemView.findViewById(R.id.txtWolofCRWA);



                // Initialisation des layouts
                layoutDefinition = itemView.findViewById(R.id.layoutDefinition);
                layoutDefinition.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
                layoutCRF = itemView.findViewById(R.id.layoutCRF);
                layoutCRF.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
                layoutCRWA = itemView.findViewById(R.id.layoutCRWA);
                layoutCRWA.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
                layoutButtonAn = itemView.findViewById(R.id.layoutButtonAn);
                layoutButtonAn.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

                itemView.setOnClickListener(view -> {
                    int Defmess = (txtDefMessageAn.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                    int Def = (txtDefinitionAn.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                    int Frmess = (txtMessageCRF.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRF, new AutoTransition());
                    int French = (txtFrenchCRF.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRF, new AutoTransition());
                    int Wolmess = (txtMessageCRWA.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRWA, new AutoTransition());
                    int Wol = (txtWolofCRWA.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRWA, new AutoTransition());



                    txtDefMessageAn.setVisibility(Defmess);
                    txtDefinitionAn.setVisibility(Def);
                    txtMessageCRF.setVisibility(Frmess);
                    txtFrenchCRF.setVisibility(French);
                    txtMessageCRWA.setVisibility(Wolmess);
                    txtWolofCRWA.setVisibility(Wol);

                });




            }

            void setDetailMotsAnglais(Anglais anglais){
                txtWordsAn.setText(anglais.getWord());
                txtDefinitionAn.setText(anglais.getDefinition());
                txtFrenchCRF.setText(anglais.getFrench());
                txtWolofCRWA.setText(anglais.getWolof());
            }

        }
        public void filterList(ArrayList<Anglais> filterllist) {
            // below line is to add our filtered
            // list in our course array list.
            anglaisArrayList = filterllist;
            // below line is to notify our adapter
            // as change in recycler view data.
            notifyDataSetChanged();
        }


    }


