package com.example.dictionnairefrangwolof.Controller.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.R;
import com.example.dictionnairefrangwolof.Vue.Main.MainActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminFrAffichage extends AppCompatActivity {
    Toolbar toolbar;
    private ImageButton btnImgAjouter;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    ArrayList<Mots> etudiants;
    AdaptateurFrancaisAdmin recylerAdapter;
    private ProgressBar loadingPB;

    SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.administration);
        toolbar=findViewById(R.id.toolbar_admin);
        setSupportActionBar(toolbar);
        swipeRefreshLayout=findViewById(R.id.swipes);

//        loadingPB = findViewById(R.id.idProgressBar);
        btnImgAjouter = findViewById(R.id.buttonAddImage);
        btnImgAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), AjoutFrancaisAdmin.class);
                startActivity(i);
            }
        });

        swipeRefreshLayout.setOnRefreshListener(() -> {

            swipeRefreshLayout.setRefreshing(false);
        });

        recyclerView = findViewById(R.id.recyle);
        //FirebaseDatabase.getInstance().getReference("Mots").keepSynced(true);
        bulid();
    }


    public void bulid(){

        databaseReference = FirebaseDatabase.getInstance().getReference("Mots").child("Francais");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        etudiants = new ArrayList<>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                etudiants.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                //    loadingPB.setVisibility(View.GONE);

                    etudiants.add(dataSnapshot.getValue(Mots.class));
                }

                recylerAdapter.notifyDataSetChanged();
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });    //databaseReference.addListenerForSingleValueEvent(valueEventListener)
        recylerAdapter = new AdaptateurFrancaisAdmin(etudiants, getApplicationContext());
        recyclerView.setAdapter(recylerAdapter);
    }


    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<Mots> filteredlist = new ArrayList<>();

        // running a for loop to compare elements.
        for (Mots item : etudiants) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getMot().toLowerCase().contains(text.toLowerCase()) ) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "Vide..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            recylerAdapter.filterList(filteredlist);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_menu,menu);
        getMenuInflater().inflate(R.menu.search_menu_fr,menu);
        MenuItem searchItem=menu.findItem(R.id.search_french);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setQueryHint("Rechercher un mot");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filter(s);
                return false;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemSelect=item.getItemId();

        switch(itemSelect){
            case R.id.wolof:
                Intent i = new Intent(AdminFrAffichage.this, AdminWolAffichage.class);
                startActivity(i);
                Toast.makeText(getApplicationContext(), "Wolof", Toast.LENGTH_SHORT).show();
        }

        switch(itemSelect){
            case R.id.anglais:
                Intent i1 = new Intent(AdminFrAffichage.this, AdminAngAffichage.class);
                startActivity(i1);
        }

        switch(itemSelect){
            case R.id.francais:
                Toast.makeText(this, "Francais", Toast.LENGTH_SHORT).show();
        }


        if (itemSelect == R.id.item_meenu_dec) {
            FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
            firebaseAuth.signOut();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }


        return super.onOptionsItemSelected(item);
    }
}
