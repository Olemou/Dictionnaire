package com.example.dictionnairefrangwolof.Vue.NavigationDrawer;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import com.example.dictionnairefrangwolof.Controller.Admin.AdminFrAffichage;
import com.example.dictionnairefrangwolof.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**

 * create an instance of this fragment.
 */
public class ConnexionFragment extends Fragment {

    private FirebaseAuth mAuth;
    private SwitchCompat switchCompat;
    EditText emaileddit,motpass;
    Button bt;
    Boolean passwordVisible;
    public ConnexionFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.test_admin, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
              emaileddit=view.findViewById(R.id.emailt);
              motpass=view.findViewById(R.id.passwordt);
               bt=view.findViewById(R.id.connexion_admint);

               switchCompat = view.findViewById(R.id.switchPassword);


               /*motpass.setOnTouchListener(new View.OnTouchListener() {
                   @Override
                   public boolean onTouch(View view, MotionEvent event) {
                       final int Right = 2;
                       if (event.getAction()== MotionEvent.ACTION_UP){
                           if (event.getRawX()>=motpass.getRight()-motpass.getCompoundDrawables()[Right].getBounds().width()){
                               int selection = motpass.getSelectionEnd();
                               if(passwordVisible){
                                   motpass.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,R.drawable.ic_eyes_off,0);
                                   //cacher le mot de passe
                                   motpass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                                   passwordVisible = false;
                               } else{

                                   motpass.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,R.drawable.ic_eyes_on,0);
                                   //Afficher le mot de passe
                                   motpass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                                   passwordVisible = true;
                               }
                               motpass.setSelection(selection);
                               return true;
                           }
                       }
                       return false;
                   }
               });

                */

              /* switchCompat.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {

                   }
               });

               */

               bt.setOnClickListener(view1 -> {

                   String login = emaileddit.getText().toString();
                   String password = motpass.getText().toString();
                   if (TextUtils.isEmpty(login)){
                       emaileddit.setError("Login vide ");
                   } else if (TextUtils.isEmpty(password)){
                       motpass.setError("Mot de passe vide");
                   } else {
                       mAuth = FirebaseAuth.getInstance();

                       mAuth.signInWithEmailAndPassword(emaileddit.getText().toString(),motpass.getText().toString()).addOnSuccessListener(authResult -> {
                           Intent intent=new Intent(getContext(), AdminFrAffichage.class);
                           startActivity(intent);
                       }).addOnFailureListener(e -> Toast.makeText(getContext(), "Login ou mot de passe incorrect ", Toast.LENGTH_SHORT).show());
                   }



               });

    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseAuth firebaseAuth=FirebaseAuth.getInstance();
        FirebaseUser firebaseUser=firebaseAuth.getCurrentUser();
        if(firebaseUser!=null){
            startActivity(new Intent(getContext(), AdminFrAffichage.class));
        }
    }
}
