package com.example.dictionnairefrangwolof.Controller.Francais;

import android.animation.LayoutTransition;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.R;

import java.util.ArrayList;

public class adaptateurFr extends RecyclerView.Adapter<adaptateurFr.ViewHolder> implements Filterable {


    ArrayList<Mots> motsArrayList;
    ArrayList<Mots> NewMotsArrayList;
    Context context;

    public adaptateurFr(ArrayList<Mots> motsArrayList, Context context) {
        this.motsArrayList = motsArrayList ;
        this.context = context;
        NewMotsArrayList=new ArrayList<>(motsArrayList);
    }

    public void filterList(ArrayList<Mots> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        motsArrayList = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public adaptateurFr.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.liste_francais,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adaptateurFr.ViewHolder holder, int position) {

        Mots mot = motsArrayList.get(position);
        holder.setDetailsEtudiant(mot);
    }

    @Override
    public int getItemCount() {
        return motsArrayList.size();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }
    private Filter exampleFilter= new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Mots>FilteretudiantArrayList=new ArrayList<>();
            if(charSequence.toString().isEmpty()||charSequence.length()==0){
                FilteretudiantArrayList.addAll(NewMotsArrayList)  ;
            } else{
                String motSaisie=charSequence.toString().toLowerCase();
                for(Mots mots:NewMotsArrayList){
                    if(mots.getMot().toLowerCase().contains(motSaisie)){
                        FilteretudiantArrayList.add(mots);

                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=FilteretudiantArrayList;
            return  filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            motsArrayList.clear();
            motsArrayList.addAll((ArrayList)filterResults.values);
            notifyDataSetChanged();

        }
    };

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtMotFr;
        private final TextView txtTypeFr;
        private final TextView txtTypeMessageFr;
        private final TextView txtDescriptionFr;
        private final TextView txtDescMessageFr;
        private final TextView txtMessageCra;
        private final TextView txtAnglaisCRA;
        private final TextView txtMessageCRW;
        private final TextView txtWolofCRW;
        Button modifier, suprimmer;
        LinearLayout layoutType, layoutDefinition, layoutCRA, layoutButton, layoutCRW;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialisation de nos variables
            txtMotFr = itemView.findViewById(R.id.txtMotsFr);
            txtTypeMessageFr = itemView.findViewById(R.id.txtTypeMessageFr);
            txtTypeFr = itemView.findViewById(R.id.txtTypeFr);
            txtDescMessageFr = itemView.findViewById(R.id.txtDescMessageFr);
            txtDescriptionFr = itemView.findViewById(R.id.txtDescriptionFr);
            txtMessageCra = itemView.findViewById(R.id.txtMessageCRA);
            txtAnglaisCRA = itemView.findViewById(R.id.txtAnglaisCRA);
            txtMessageCRW = itemView.findViewById(R.id.txtMessageCRW);
            txtWolofCRW = itemView.findViewById(R.id.txtWolofCRW);

            modifier = itemView.findViewById(R.id.btnModifier);
            suprimmer = itemView.findViewById(R.id.btnSuprimmer);

            // Initialisation des layouts
            layoutType = itemView.findViewById(R.id.layoutType);
            layoutType.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutDefinition = itemView.findViewById(R.id.layoutDefinition);
            layoutDefinition.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRA = itemView.findViewById(R.id.layoutCRA);
            layoutCRA.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRW = itemView.findViewById(R.id.layoutCRW);
            layoutCRW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);


            // Bouton drop down pour afficher
            itemView.setOnClickListener(view -> {
                int typemess = (txtTypeMessageFr.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutType, new AutoTransition());
                int type = (txtTypeFr.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutType, new AutoTransition());
                int defmess = (txtDescMessageFr.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                int def = (txtDescriptionFr.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutDefinition, new AutoTransition());
                int CRAmess = (txtMessageCra.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRA, new AutoTransition());
                int CRA = (txtAnglaisCRA.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRA, new AutoTransition());
                int CRWmess = (txtMessageCRW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRW, new AutoTransition());
                int CRW = (txtWolofCRW.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
                TransitionManager.beginDelayedTransition(layoutCRW, new AutoTransition());



                txtTypeMessageFr.setVisibility(typemess);
                txtTypeFr.setVisibility(type);
                txtDescMessageFr.setVisibility(defmess);
                txtDescriptionFr.setVisibility(def);
                txtMessageCra.setVisibility(CRAmess);
                txtAnglaisCRA.setVisibility(CRA);
                txtMessageCRW.setVisibility(CRWmess);
                txtWolofCRW.setVisibility(CRW);


            });
        }

        void setDetailsEtudiant(Mots mot) {
            txtMotFr.setText(mot.getMot());
            txtTypeFr.setText(mot.getType());
            txtDescriptionFr.setText(mot.getDefinition());
            txtAnglaisCRA.setText(mot.getCorespondanceAnglais());
            txtWolofCRW.setText(mot.getCorespondanceWolof());


        }
    }


}