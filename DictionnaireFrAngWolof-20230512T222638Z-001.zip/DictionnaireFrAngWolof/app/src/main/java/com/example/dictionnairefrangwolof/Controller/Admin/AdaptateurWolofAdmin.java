package com.example.dictionnairefrangwolof.Controller.Admin;

import android.animation.LayoutTransition;
import android.app.AlertDialog;
import android.content.Context;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionnairefrangwolof.Model.Anglais.Anglais;
import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.Model.Wolof.Wolof;
import com.example.dictionnairefrangwolof.R;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AdaptateurWolofAdmin extends RecyclerView.Adapter<AdaptateurWolofAdmin.ViewHolder> implements Filterable {

    ArrayList<Wolof> wolofArrayList;
    ArrayList<Wolof> NewwolofArrayList;
    Context context;

    public AdaptateurWolofAdmin(ArrayList<Wolof> wolofArrayList, Context context) {
        this.wolofArrayList = wolofArrayList;
        this.context = context;
        NewwolofArrayList=new ArrayList<>(wolofArrayList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_mot_wol_admin,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Wolof wolof = wolofArrayList.get(position);
        holder.setDetailsMotsWolof(wolof);
        String motsupp = wolof.getMot();

        holder.suprimmer.setOnClickListener(view -> {

            AlertDialog.Builder builder=new AlertDialog.Builder(holder.txtMotWol.getContext());
            builder.setTitle("ATTENTION");
            builder.setMessage("Voulez-vous suprimmer les données  ?");
            builder.setPositiveButton("OUI", (dialogInterface, i) -> FirebaseDatabase.getInstance().getReference("Mots").child("Wolof").
                    child(motsupp).removeValue()).setNegativeButton("NON", (dialogInterface, i) -> {
            });
            builder.show();
        });

        holder.modifier.setOnClickListener(view -> {
            final DialogPlus dialog = DialogPlus.newDialog(holder.txtMotWol.getContext())
                    .setContentHolder(new com.orhanobut.dialogplus.ViewHolder(R.layout.update_mot_wol_admin))
                    .setExpanded(true,900)
                    .create();
            View v=dialog.getHolderView();

            EditText editMotsWol = v.findViewById(R.id.editMotsWol);
            EditText editMotsCRAW = v.findViewById(R.id.editMotsCRAW);
            EditText editMotsCRFW = v.findViewById(R.id.editMotsCRFW);

            Button buttonModifier;
            buttonModifier=v.findViewById(R.id.btnModifiermotsWol);

            editMotsWol.setText(wolof.getMot());
            editMotsCRAW.setText(wolof.getAnglais());
            editMotsCRFW.setText(wolof.getFrancais());
            dialog.show();

            buttonModifier.setOnClickListener(view1 -> {
                Map<String, Object> mots = new HashMap<>();
                mots.put("Mot", editMotsWol.getText().toString());
                mots.put("Anglais",editMotsCRAW.getText().toString());
                mots.put("Francais",editMotsCRFW.getText().toString());
                FirebaseDatabase.getInstance().getReference("Mots").child("Wolof")
                        .child(editMotsWol.getText().toString()).updateChildren(mots).addOnSuccessListener(unused -> {
                    dialog.dismiss();
                    Toast.makeText(context.getApplicationContext(), "succes", Toast.LENGTH_SHORT).show();
                });

            });




        });
    }

    @Override
    public int getItemCount() {
        return wolofArrayList.size();
    }

    public void filterList(ArrayList<Wolof> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        wolofArrayList = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }


    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private Filter exampleFilter= new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Wolof>FilteretudiantArrayList=new ArrayList<>();
            if(charSequence.toString().isEmpty()||charSequence.length()==0){
                FilteretudiantArrayList.addAll(NewwolofArrayList)  ;
            } else{
                String motSaisie=charSequence.toString().toLowerCase();
                for(Wolof wolof:NewwolofArrayList){
                    if(wolof.getMot().toLowerCase().contains(motSaisie)){
                        FilteretudiantArrayList.add(wolof);

                    }
                }
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=FilteretudiantArrayList;
            return  filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            wolofArrayList.clear();
            wolofArrayList.addAll((ArrayList)filterResults.values);
            notifyDataSetChanged();

        }
    };



    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txtMotWol, txtMessageCRAW, txtAnglaisCRAW, txtMessageCRFW, txtFrancaisCRFW;
        Button modifier, suprimmer;
        LinearLayout  layoutCRAW, layoutCRFW, layoutButtonWol;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtMotWol = itemView.findViewById(R.id.txtMotsWol);
            txtMessageCRAW = itemView.findViewById(R.id.txtMessageCRAW);
            txtAnglaisCRAW = itemView.findViewById(R.id.txtAnglaisCRAW);
            txtMessageCRFW = itemView.findViewById(R.id.txtMessageCRFW);
            txtFrancaisCRFW = itemView.findViewById(R.id.txtFrancaisCRFW);

            modifier = itemView.findViewById(R.id.btnModifierWol);
            suprimmer = itemView.findViewById(R.id.btnSuprimmerWol);

            layoutCRAW = itemView.findViewById(R.id.layoutCRAW);
            layoutCRAW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutCRFW = itemView.findViewById(R.id.layoutCRFW);
            layoutCRFW.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
            layoutButtonWol = itemView.findViewById(R.id.layoutButtonWol);
            layoutButtonWol.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int txtMessCRAW = (txtMessageCRAW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRAW, new AutoTransition());
                    int AnglaisCRAW = (txtAnglaisCRAW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRAW, new AutoTransition());
                    int txtMessCRFW= (txtMessageCRFW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRFW, new AutoTransition());
                    int FrancaisCRFW = (txtFrancaisCRFW.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutCRFW, new AutoTransition());

                    int btnmodif = (modifier.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutButtonWol, new AutoTransition());
                    int btnsup = (suprimmer.getVisibility() == View.GONE)? View.VISIBLE: View.GONE;
                    TransitionManager.beginDelayedTransition(layoutButtonWol, new AutoTransition());

                    txtMessageCRAW.setVisibility(txtMessCRAW);
                    txtAnglaisCRAW.setVisibility(AnglaisCRAW);
                    txtMessageCRFW.setVisibility(txtMessCRFW);
                    txtFrancaisCRFW.setVisibility(FrancaisCRFW);

                    modifier.setVisibility(btnmodif);
                    suprimmer.setVisibility(btnsup);


                }
            });
        }

        void setDetailsMotsWolof(Wolof wolof) {
            txtMotWol.setText(wolof.getMot());
            txtAnglaisCRAW.setText(wolof.getAnglais());
            txtFrancaisCRFW.setText(wolof.getFrancais());

        }
    }
}
