package com.example.dictionnairefrangwolof.Controller.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.dictionnairefrangwolof.Model.Anglais.Anglais;
import com.example.dictionnairefrangwolof.Model.Francais.Mots;
import com.example.dictionnairefrangwolof.R;
import com.example.dictionnairefrangwolof.Vue.Main.MainActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminAngAffichage extends AppCompatActivity {
    private ImageButton btnImgAjouterANG;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    ArrayList<Anglais> etudiants;
    AdaptateurAnglaisAdmin recylerAdapter;
    private ProgressBar loadingPB;
    Toolbar toolbar;
    SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_ang_affichage);

        btnImgAjouterANG = findViewById(R.id.buttonAddImageAng);
        btnImgAjouterANG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdminAngAffichage.this, AjoutAnglaisAdmin.class);
                startActivity(i);
            }
        });

        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        swipeRefreshLayout=findViewById(R.id.swipes);

        swipeRefreshLayout.setOnRefreshListener(() -> {
            bulid();
            swipeRefreshLayout.setRefreshing(false);
        });

        recyclerView = findViewById(R.id.recyleAnglais);
        FirebaseDatabase.getInstance().getReference("Mots").keepSynced(true);
        bulid();

    }
    public void bulid(){

        databaseReference = FirebaseDatabase.getInstance().getReference("Mots").child("Anglais");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        etudiants = new ArrayList<>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                etudiants.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    // loadingPB.setVisibility(View.GONE);

                    etudiants.add(dataSnapshot.getValue(Anglais.class));
                }

                recylerAdapter.notifyDataSetChanged();
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });    //databaseReference.addListenerForSingleValueEvent(valueEventListener)
        recylerAdapter = new AdaptateurAnglaisAdmin(etudiants, getApplicationContext());
        recyclerView.setAdapter(recylerAdapter);
    }


    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<Anglais> filteredlist = new ArrayList<>();

        // running a for loop to compare elements.
        for (Anglais item : etudiants) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getWord().toLowerCase().contains(text.toLowerCase()) ) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "Empty..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            recylerAdapter.filterList(filteredlist);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_menu,menu);
        getMenuInflater().inflate(R.menu.search_menu_fr,menu);
        MenuItem searchItem=menu.findItem(R.id.search_french);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setQueryHint("Search a word");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filter(s);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch ((item.getItemId())){


            case R.id.francais:
                Intent i = new Intent(AdminAngAffichage.this, AdminFrAffichage.class);
                startActivity(i);
                Toast.makeText(this, "French", Toast.LENGTH_SHORT).show();
                break;

            case R.id.anglais:

                Toast.makeText(this, "English ", Toast.LENGTH_SHORT).show();

                break;

            case R.id.wolof:
                Intent i1 = new Intent(AdminAngAffichage.this, AdminWolAffichage.class);
                startActivity(i1);
                Toast.makeText(this, "Wolof", Toast.LENGTH_SHORT).show();
                break;

            case R.id.item_meenu_dec:
                FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
                firebaseAuth.signOut();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                break;



        }
        return super.onOptionsItemSelected(item);
    }

}